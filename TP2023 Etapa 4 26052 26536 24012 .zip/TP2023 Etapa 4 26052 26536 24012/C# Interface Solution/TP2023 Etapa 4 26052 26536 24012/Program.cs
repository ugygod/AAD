﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace AAD
{
    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = "Data Source=DESKTOP-GPI88KG;Initial Catalog=Isuits;Integrated Security=True";
            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    CriarStoredProcedures(connection);

                    var cmd = connection.CreateCommand();
                    bool continuar = true;
                    while (continuar)
                    {
                        Console.WriteLine("Escolha uma opção:");
                        Console.WriteLine("1. Inserir instituição");
                        Console.WriteLine("2. Editar instituição");
                        Console.WriteLine("3. Eliminar instituição");
                        Console.WriteLine("4. Mostrar informação prestadores");
                        Console.WriteLine("5. Sair");
                        var opcao = Console.ReadLine();

                        switch (opcao)
                        {
                            case "1":
                                InserirDados(cmd);
                                break;
                            case "2":
                                EditarDados(cmd);
                                break;
                            case "3":
                                EliminarDados(cmd);
                                break;
                            case "4":
                                MostrarInfoPrestadores(cmd);
                                break;
                            case "5":
                                continuar = false;
                                break;
                            default:
                                Console.WriteLine("Opção inválida.");
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu um erro: " + ex.Message);
                }
            }
        }

        static void CriarStoredProcedures(SqlConnection connection)
        {
            var script = @"
            CREATE OR ALTER PROCEDURE spInserirInstituicao
                @IDInst char(8),
                @NomeInst char(100),
                @CPostal char(8),
                @IDContacto int
            AS
            BEGIN
                INSERT INTO INSTITUICAO (IDInst, NomeInst, CPostal, IDContacto) 
                VALUES (@IDInst, @NomeInst, @CPostal, @IDContacto);
            END;

            CREATE OR ALTER PROCEDURE spEditarInstituicao
                @IDInst char(8),
                @NomeInst char(100),
                @CPostal char(8),
                @IDContacto int
            AS
            BEGIN
                UPDATE INSTITUICAO
                SET NomeInst = @NomeInst, CPostal = @CPostal, IDContacto = @IDContacto
                WHERE IDInst = @IDInst;
            END;

            CREATE OR ALTER PROCEDURE spEliminarInstituicao
                @IDInst char(8)
            AS
            BEGIN
                DELETE FROM INSTITUICAO WHERE IDInst = @IDInst;
            END;
            ";

            using (var command = new SqlCommand(script, connection))
            {
                command.ExecuteNonQuery();
            }

            Console.WriteLine("Stored Procedures criadas/atualizadas com sucesso.");
        }

        static void InserirDados(SqlCommand cmd)
        {
            Console.WriteLine("Inserir nova instituição...");
            // Recolha de dados da instituição
            Console.Write("Digite o código da instituição: ");
            var codInstituicao = Convert.ToInt32(Console.ReadLine());
            Console.Write("Digite o nome da instituição: ");
            var nomeInstituicao = Console.ReadLine();
            Console.Write("Digite o código postal da instituição: ");
            var codigoPostal = Console.ReadLine();
            // Recolha de dados do contacto
            Console.Write("Digite o código do tipo de contacto: ");
            var tipoContacto = Console.ReadLine();
            Console.Write("Digite o número de telemóvel do contacto: ");
            var telemovel = Console.ReadLine();
            Console.Write("Digite o email do contacto: ");
            var email = Console.ReadLine();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spInserirInstituicao";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@IDInst", codInstituicao);
            cmd.Parameters.AddWithValue("@NomeInst", nomeInstituicao);
            cmd.Parameters.AddWithValue("@CPostal", codigoPostal);
            cmd.Parameters.AddWithValue("@IDTipoContacto", tipoContacto);
            cmd.Parameters.AddWithValue("@Telemovel", telemovel);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Instituição inserida com sucesso.");
        }

        static void EditarDados(SqlCommand cmd)
        {
            Console.WriteLine("Editar dados de uma instituição...");
            Console.Write("Digite o ID da instituição que deseja editar: ");
            var idInstituicao = Convert.ToInt32(Console.ReadLine());
            Console.Write("Digite o novo nome da instituição: ");
            var nomeInstituicao = Console.ReadLine();
            Console.Write("Digite o novo código postal da instituição: ");
            var codigoPostal = Console.ReadLine();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spEditarInstituicao";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@IDInst", idInstituicao);
            cmd.Parameters.AddWithValue("@NomeInst", nomeInstituicao);
            cmd.Parameters.AddWithValue("@CPostal", codigoPostal);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Dados da instituição atualizados com sucesso.");
        }

        static void EliminarDados(SqlCommand cmd)
        {
            Console.WriteLine("Eliminar uma instituição...");
            Console.Write("Digite o ID da instituição que deseja eliminar: ");
            var idInstituicao = Convert.ToInt32(Console.ReadLine());

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spEliminarInstituicao";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@IDInst", idInstituicao);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Instituição eliminada com sucesso.");
        }

        static void MostrarInfoPrestadores(SqlCommand cmd)
        {
            try
            {
                Console.WriteLine("Mostrar informações dos prestadores...");

                // SQL query to retrieve information about prestadores
                string sqlQuery = @"
            SELECT 
                P.IDPrestador,
                P.Nome AS NomePrestador,
                C.Telemovel,
                C.Email,
                M.Localidade,
                M.Concelho,
                M.Distrito,
                IB.NomeTitular,
                IB.IBAN,
                B.Nome AS NomeBanco,
                B.SWIFT
            FROM 
                PRESTADOR P
                LEFT JOIN CONTACTO C ON P.IDContacto = C.IDContacto
                LEFT JOIN MORADA M ON P.CPostal = M.CPostal
                LEFT JOIN INFO_BANCARIA IB ON P.IDBancaria = IB.IDBancaria
                LEFT JOIN BANCO B ON IB.IDBanco = B.IDBanco";

                cmd.CommandText = sqlQuery;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("IDPrestador\tNomePrestador\tTelemovel\tEmail\tLocalidade\tConcelho\tDistrito\tNomeTitular\tIBAN\tNomeBanco\tSWIFT");
                    while (reader.Read())
                    {
                        int idPrestador = reader.GetInt32(0);
                        string nomePrestador = reader.GetString(1);
                        string telemovel = reader.IsDBNull(2) ? "N/A" : reader.GetString(2);
                        string email = reader.IsDBNull(3) ? "N/A" : reader.GetString(3);
                        string localidade = reader.IsDBNull(4) ? "N/A" : reader.GetString(4);
                        string concelho = reader.IsDBNull(5) ? "N/A" : reader.GetString(5);
                        string distrito = reader.IsDBNull(6) ? "N/A" : reader.GetString(6);
                        string nomeTitular = reader.IsDBNull(7) ? "N/A" : reader.GetString(7);
                        string iban = reader.IsDBNull(8) ? "N/A" : reader.GetString(8);
                        string nomeBanco = reader.IsDBNull(9) ? "N/A" : reader.GetString(9);
                        string swift = reader.IsDBNull(10) ? "N/A" : reader.GetString(10);

                        Console.WriteLine($"{idPrestador}\t\t{nomePrestador}\t\t{telemovel}\t\t{email}\t\t{localidade}\t\t{concelho}\t\t{distrito}\t\t{nomeTitular}\t\t{iban}\t\t{nomeBanco}\t\t{swift}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao mostrar informações dos prestadores: " + ex.Message);
            }
        }
    }
}

