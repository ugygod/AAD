/* Quantos prestadores existem em cada distrito, e qual � o valor m�dio das suas informa��es banc�rias, agrupados por distrito e ordenados pelo n�mero de prestadores? */
SELECT M.Distrito, COUNT(P.IDPrestador) AS TotalPrestadores, AVG(P.IDBancaria) AS MediaIDBancaria
FROM PRESTADOR P
LEFT JOIN MORADA M ON P.CPostal = M.CPostal
GROUP BY M.Distrito
ORDER BY COUNT(P.IDPrestador) DESC;

/* Qual � a rela��o entre os tipos de contacto e a localidade dos prestadores, mostrando apenas aqueles que t�m mais de 5 contactos de um mesmo tipo? */
SELECT C.IDTipoContacto, M.Localidade, COUNT(C.IDContacto) AS NumeroContatos
FROM CONTACTO C
JOIN PRESTADOR P ON C.IDContacto = P.IDContacto
JOIN MORADA M ON P.CPostal = M.CPostal
GROUP BY C.IDTipoContacto, M.Localidade
HAVING COUNT(C.IDContacto) > 5;

/* Quais s�o os prestadores que t�m tanto uma identifica��o biom�trica como um contacto telef�nico, e qual � a soma das suas identifica��es biom�tricas? */
SELECT P.IDPrestador, P.Nome, SUM(B.IDBio) AS SomaIDBio
FROM PRESTADOR P
JOIN ID_BIOMETRICA B ON P.IDBio = B.IDBio
JOIN CONTACTO C ON P.IDContacto = C.IDContacto
WHERE C.Telemovel IS NOT NULL
GROUP BY P.IDPrestador, P.Nome;

/* Qual � a soma das identifica��es banc�rias dos prestadores que t�m mais de uma identifica��o biom�trica, agrupados por localidade? */
SELECT M.Localidade, SUM(P.IDBancaria) AS SomaIDBancaria
FROM PRESTADOR P
JOIN ID_BIOMETRICA B ON P.IDBio = B.IDBio
JOIN MORADA M ON P.CPostal = M.CPostal
GROUP BY M.Localidade
HAVING COUNT(B.IDBio) > 1;

/* Quais s�o os distritos que t�m prestadores com contactos de email e telem�vel, ordenados pelo n�mero total de contactos desses tipos? */
SELECT M.Distrito, COUNT(C.IDContacto) AS TotalContatos
FROM CONTACTO C
JOIN PRESTADOR P ON C.IDContacto = P.IDContacto
JOIN MORADA M ON P.CPostal = M.CPostal
WHERE C.Email IS NOT NULL AND C.Telemovel IS NOT NULL
GROUP BY M.Distrito
ORDER BY COUNT(C.IDContacto) DESC;

/* Combina��o de prestadores com e sem identifica��o biom�trica por concelho, mostrando a m�dia das identifica��es banc�rias para cada grupo? */
SELECT M.Concelho, B.Bio, AVG(P.IDBancaria) AS MediaIDBancaria
FROM (SELECT IDPrestador, CASE WHEN IDBio IS NOT NULL THEN 'Com Bio' ELSE 'Sem Bio' END AS Bio
    FROM PRESTADOR) B
JOIN PRESTADOR P ON B.IDPrestador = P.IDPrestador
JOIN MORADA M ON P.CPostal = M.CPostal
GROUP BY M.Concelho, B.Bio;

/* Identificar prestadores que t�m mais de 3 tipos de contacto diferentes, listando nomes e o total de tipos de contacto? */
SELECT P.Nome, COUNT(DISTINCT C.IDTipoContacto) AS TiposDeContato
FROM PRESTADOR P
JOIN CONTACTO C ON P.IDContacto = C.IDContacto
GROUP BY P.Nome
HAVING COUNT(DISTINCT C.IDTipoContacto) > 3;

/* Encontrar a localidade com o maior n�mero de prestadores, mostrando o nome da localidade e o n�mero total de prestadores? */
SELECT M.Localidade, COUNT(P.IDPrestador) AS TotalPrestadores
FROM MORADA M
JOIN PRESTADOR P ON M.CPostal = P.CPostal
GROUP BY M.Localidade
HAVING COUNT(P.IDPrestador) >= all (SELECT COUNT(P.IDPrestador) AS TotalPrestadores
FROM MORADA M
JOIN PRESTADOR P ON M.CPostal = P.CPostal
GROUP BY M.Localidade);

/* Comparar o n�mero de prestadores com e sem impress�o biom�trica em cada distrito?*/
SELECT M.Distrito, 
       SUM(CASE WHEN B.Impressao IS NOT NULL THEN 1 ELSE 0 END) AS ComImpressao, 
       SUM(CASE WHEN B.Impressao IS NULL THEN 1 ELSE 0 END) AS SemImpressao
FROM MORADA M
JOIN PRESTADOR P ON M.CPostal = P.CPostal
LEFT JOIN ID_BIOMETRICA B ON P.IDBio = B.IDBio
GROUP BY M.Distrito;

/* Listar os prestadores que t�m tanto um email quanto um telem�vel, com a soma das suas identifica��es banc�rias, ordenados pela soma em ordem decrescente? */
SELECT P.Nome, SUM(P.IDBancaria) AS SomaIDBancaria
FROM PRESTADOR P
JOIN CONTACTO C ON P.IDContacto = C.IDContacto
WHERE C.Email IS NOT NULL AND C.Telemovel IS NOT NULL
GROUP BY P.Nome
ORDER BY SUM(P.IDBancaria) DESC;
